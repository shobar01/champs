<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class ReportExcelExport implements FromView
{
    public function __construct($ikdoutlet, $itgl, $itype)
    {
        $this->ikdoutlet = $ikdoutlet;
        $this->itgl = $itgl;
        $this->itype = $itype;
    }

    public function view(): View
    {

        $client = new \GuzzleHttp\Client();
        $ikdoutlet = $this->ikdoutlet;
        $itgl = $this->itgl;
        $itype = $this->itype;
        $tanggalll = $this->itgl;

        $response = $client->post('http://mspoon.online/mspoon_pos/openorder.php', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'kdoutlet' => $ikdoutlet,
                'tglorder' => $itgl,
            ],
        ]);

        $jsons = $response->getBody()->getContents();
        $json = json_decode($jsons, true);
        //tglorder,tglterima,kdorderbarang,wktorder

        $tglord = $json['order'][0]['tglorder'];
        $tgltrm = $json['order'][0]['tglterima'];
        $kdbrng = $json['order'][0]['kdorderbarang'];
        $wktord = $json['order'][0]['wktorder'];
        $detail = $json['order'][0]['detail'];

        return view('rptorderbrg.areaPDF', compact('detail', 'itgl', 'kdbrng', 'tanggalll'));

    }

}
