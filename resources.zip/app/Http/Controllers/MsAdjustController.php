<?php

namespace App\Http\Controllers;

use App\Exports\SuaraKaryawanExcelExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use View;

class MsAdjustController extends Controller
{
    //  http://localhost/champs-mobile/adjustms?kdakses=AVMS2&nip=K1070077&kdoutlet=MSJ03  
    public function adjustms(Request $request)
    {
        $client = new \GuzzleHttp\Client();

        $ttgl = date('Y-m-d');  
        
        if (isset($_GET['nip'])) {  
            $nip = $_GET['nip']; 
        } else { 
            $nip = '';
        }
        if (isset($_GET['inpt_noorder']) ) {
            $noorder = $_GET['inpt_noorder'];   
            $itgl = $_GET['tgl_noorder'];
            
        } else {
            $noorder = "";  
            $itgl = $ttgl; 
        } 
        $tanggalll = Carbon::parse($itgl)->translatedFormat('l, d F Y');
        $rspadjst = $client->post('http://mspoon.online/mspoon_pos/scadjtrx.php', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'json' => [  
                'noorder' => $noorder, 
            ],
        ]
        );
            
        
        $jsnbdy = $rspadjst->getBody()->getContents();
        $jsrslt = json_decode($jsnbdy, true); 
            
         

        return view('msadjust.adjust', compact( 'jsrslt','itgl','tanggalll','noorder','nip')); 
      

    }
    public function submit_adjust()
    { 
         
        $client = new \GuzzleHttp\Client(); 
        $nip            = $_POST['nip'];
        $inpt_nor       = $_POST['inpt_nor'];
        $inpt_tgl       = $_POST['inpt_tgl'];    
        
        $ttgl = date('Y-m-d');  
        $rspnprmhn = $client->post('http://mspoon.online/mspoon_pos/scadjust.php', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'nip' => $nip,
                'noorder' => $inpt_nor,
                'tglclosing' => $inpt_tgl, 
            ],

        ]);
        $jsnbdy = $rspnprmhn->getBody()->getContents();
        $jsrslt = json_decode($jsnbdy, true); 

        if($ttgl != $inpt_tgl){
            $rspredfr = $client->post('http://mspoon.online/mspoon_pos/recalldfr.php', [
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'kdoutlet' => substr($inpt_nor,0,5),
                    'tanggal' => $inpt_tgl,
                ],
    
            ]);
            $jsnbdydfr = $rspredfr->getBody()->getContents();
            $jsrsltdfr = json_decode($jsnbdydfr, true); 

            $rspresync = $client->post('http://mspoon.online/mspoon_pos/recalldfr.php', [
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'kdoutlet' => substr($inpt_nor,0,5),
                    'tanggal' => $inpt_tgl,
                ],
    
            ]);
            $jsnbdysync = $rspresync->getBody()->getContents();
            $jsrsltsync = json_decode($jsnbdysync, true); 
 
        };
        return response()->json($jsrslt);
    }
}
