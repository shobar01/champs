<?php

namespace App\Http\Controllers;

use App\Exports\ReportExcelExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use View;

class ReportOrderBrgController extends Controller
{
    // http://localhost/champs-mobile/repot_ob?kdoutlet=&kdakses=AVXXX&nip=K1050012
    public function repot_ob(Request $request)
    {
        $client = new \GuzzleHttp\Client();

        $ttgl = date('Y-m-d');
        if (isset($_GET['tanggal_ordbrg'])) {
            $itgl = $_GET['tanggal_ordbrg'];
        } else {
            $itgl = $ttgl;
        }
        $tanggalll = Carbon::parse($itgl)->translatedFormat('l, d F Y');
        $rspnotl = $client->post('http://api.champ-group.com/champ_dev/champ_api/cmfiturweb/getOtlMS', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'json' => [
            ],
        ]
        );
        if (isset($_GET['kdakses'])) {
            // Khusus AVMS7
            if ($_GET['nip'] == 'K1070070') {
                $kdakses = $_GET['kdakses'];
                $nip = 'K1060078';
            } else {
                $kdakses = $_GET['kdakses'];
                $nip = $_GET['nip'];
            }
        } else {
            $kdakses = 'AVXXX';
            $nip = 'A1050012';
        }
        // K1030010    Suratin Dwi Prananto
        // K1060078    Yulius Evren
        // K1070070    Leonardus Dimas Diaz Gonzales

        $jsonotls = $rspnotl->getBody()->getContents();
        $jsonotl = json_decode($jsonotls, true);

        // dd($jsonotl);

        $dfotlam = $jsonotl['df_otl'];

        $dfotl = array();
        for ($i = 0; $i < count($dfotlam); $i++) {
            if ($kdakses == 'AVXXX') {
                $det = ([
                    'kdoutlet' => $dfotlam[$i]['kdoutlet'],
                    'nmoutlet' => $dfotlam[$i]['nmoutlet'],
                    'sngktotl' => $dfotlam[$i]['sngktotl'],
                    'AM' => $dfotlam[$i]['AM'],
                ]);
                array_push($dfotl, $det);
            } else {
                if ($nip == $dfotlam[$i]['AM']) {
                    $det = ([
                        'kdoutlet' => $dfotlam[$i]['kdoutlet'],
                        'nmoutlet' => $dfotlam[$i]['nmoutlet'],
                        'sngktotl' => $dfotlam[$i]['sngktotl'],
                        'AM' => $dfotlam[$i]['AM'],
                    ]);
                    array_push($dfotl, $det);
                }
            }

        }
        if ($kdakses == 'AVMS2') {
            if (isset($_GET['kdoutlet'])) {
                $ikdoutlet = $_GET['kdoutlet'];
            }
        } else {
            if (isset($_GET['kdotl'])) {
                $ikdoutlet = $_GET['kdotl'];
            } else {
                $ikdoutlet = $dfotl[0]['kdoutlet'];
            }
        }

        // dd($dfotl);
        if (isset($_GET['dwnld_type'])) {
            $itype = $_GET['dwnld_type'];
        } else {
            $itype = 'btn_periode';
        }

        if (isset($_GET['lwttgl'])) {
            $lwttgl = $_GET['lwttgl'];
        } else {
            $lwttgl = $ttgl;
        }

        $response = $client->post('http://mspoon.online/mspoon_pos/openorder.php', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'kdoutlet' => $ikdoutlet,
                'tglorder' => $itgl,
            ],
        ]);

        $jsons = $response->getBody()->getContents();
        $json = json_decode($jsons, true);

        // tglorder,tglterima,kdorderbarang,wktorder
        if ($json['order'] == []) {
            $detail = null;
            $kdbrng = '';
            $dford = '';
            $dfkdbrng = '';
            $jmlkdord = 0;
        } else {
            // $tglord = $json['order'][0]['tglorder'];
            // $tgltrm = $json['order'][0]['tglterima'];
            // $kdbrng = $json['order'][0]['kdorderbarang'];
            // $wktord = $json['order'][0]['wktorder'];
            // $detail = $json['order'][0]['detail'];
            $tglord = $json['order'][0]['tglorder'];
            $tgltrm = $json['order'][0]['tglterima'];

            $wktord = $json['order'][0]['wktorder'];
            $detail = $json['order'];
            $dford = array();
            $dfkdbrng = array();

            $jmlkdord = count($detail);

            if ($jmlkdord == 1) {
                $kdbrng = $json['order'][0]['kdorderbarang'];
            } else {
                if (isset($_GET['txkdorgbrg'])) {
                    $kdbrng = $_GET['txkdorgbrg'];
                } else {
                    $kdbrng = $json['order'][0]['kdorderbarang'];
                }
            }

            for ($i = 0; $i < count($detail); $i++) {
                $kdbrgg = ([
                    'kdordbarang' => $detail[$i]['kdorderbarang'],
                ]);

                // dd($detail[$i]['kdorderbarang']."===".$kdbrng);
                array_push($dfkdbrng, $kdbrgg);
                if ($detail[$i]['kdorderbarang'] == $kdbrng) {
                    for ($ii = 0; $ii < count($detail[$i]['detail']); $ii++) {

                        // dd(count($detail[0]['detail'][$ii]));
                        $det = ([
                            'urutan' => $detail[$i]['detail'][$ii]['urutan'],
                            'kdbarang' => $detail[$i]['detail'][$ii]['kdbarang'],
                            'nmbarang' => $detail[$i]['detail'][$ii]['nmbarang'],
                            'satuan' => $detail[$i]['detail'][$ii]['satuan'],
                            'qty' => $detail[$i]['detail'][$ii]['qty'],
                            'kdorderbarang' => $detail[$i]['kdorderbarang'],
                        ]);
                        array_push($dford, $det);
                    }
                }
            }
        }
        // dd($dford);
        if ($itype == "btn_excel") {

            // dd("btn_excel " . $ikdoutlet . '==' . $itgl . '==' . $itype);
            // return Excel::download(new ExcelExport, 'excel.xlsx');
            return view('rptorderbrg.areaPDFf', compact('detail', 'itgl', 'kdbrng', 'tanggalll'));
            return Excel::download(new ReportExcelExport($ikdoutlet, $itgl, $itype),
                'laporan_bukutamu_periode_.xlsx');

        } elseif ($itype == "btn_pdf") {
            return view('rptorderbrg.headpdff', compact('detail', 'dford', 'itgl', 'kdbrng', 'tanggalll'));
        } else {
            return view('rptorderbrg.rptorderbrgf', compact('dfotl', 'detail', 'dford', 'dfkdbrng', 'kdbrng', 'tanggalll', 'itgl', 'ikdoutlet', 'kdakses', 'nip', 'jmlkdord'));
        }

    }

}
