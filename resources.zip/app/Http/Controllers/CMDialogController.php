<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use View;

class CMDialogController extends Controller
{
    // http://api.champ-group.com/champs-mobile/cm_dashsaran?urllotti=https://assets10.lottiefiles.com/packages/lf20_rxlpoybw.json&nip=K1050012&kdoutlet=null&kdakses=AVXXX&idtittle=02L
    public function cm_dashsaran(Request $request)
    { 
        $client = new \GuzzleHttp\Client(); 
        if (isset($_GET['urllotti'])) {
            $urllotti   = $_GET['urllotti'];
            $idtittle     = $_GET['idtittle'];
            $nip        = $_GET['nip'];     
            $kdoutlet   = $_GET['kdoutlet'];     
            $kdakses    = $_GET['kdakses'];     
        }  else {
            $urllotti   = "0";
            $idtittle     = "0";
            $nip        = "0";     
            $kdoutlet   = "0";     
            $kdakses    = "0";     
        }
        return view('cmdialog.cm_dashsaran', compact('urllotti',  'idtittle','nip','kdoutlet','kdakses'));
    }
    public function submit_dashsaran()
    { 
         
        $client = new \GuzzleHttp\Client();
        $waktu          = date('H-i-s');
        $tanggals       = date('Y-m-d');
        $nip            = $_POST['nip'];
        $idtittle       = $_POST['idtittle'];
        $isisaran       = $_POST['isisaran']; 
        $subjctt       = $_POST['subjctt']; 
        
        $rspnprmhn = $client->post('http://api.champ-group.com/champ_dev/champ_api/cmdashboardBody/setMoodSrn', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'nip' => $nip,
                'idtittle' => $idtittle,
                'isisaran' => $isisaran,
                'fotosrn' => "F", 
                'subjct' => $subjctt, 
            ],

        ]);
        $jsnbdy = $rspnprmhn->getBody()->getContents();
        $jsrslt = json_decode($jsnbdy, true);

        return response()->json($jsrslt);
    }
    public function cm_dashsaranHistory(Request $request)
    { 
        if (isset($_GET['nip'])) { 
            $nip        = $_GET['nip'];       
        }  else { 
            $nip        = "0";      
        }
        $client = new \GuzzleHttp\Client(); 
        $rspHisModsrn= $client->get('http://api.champ-group.com/champ_dev/champ_api/cmdashboardBodyV19/getHistoryMoodSrn', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'nip' => $nip,
            ],
        ]
        ); 
        $jsonHisModSrn  = $rspHisModsrn->getBody()->getContents();
        $jsHistmod      = json_decode($jsonHisModSrn, true); 
        if ($jsHistmod['success'] == 0) {
            $dfhis_mood     = null;
        }else {
            $dfhis_mood     = $jsHistmod['dfhis_mood'];
        }
        
        // dd($dfhis_mood);

        return view('cmdialog.cm_dashsaranhistory', compact('dfhis_mood'));
    }
}
