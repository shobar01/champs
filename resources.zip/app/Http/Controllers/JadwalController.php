<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use View;

class JadwalController extends Controller
{
    // http://api.champ-group.com/champ_dev/champ_api/cmjadwal/getViewJadwal?dept=ICT DEPT.
    // http://localhost/champs-mobile/public/jadwal?dept=ICT%20DEPT.
    public function jadwal(Request $request)
    {
        
        $thr = date('d');
        $bln = date('m');
        $client = new \GuzzleHttp\Client();
        $dept = $_GET['dept'];

        $response = $client->get('http://api.champ-group.com/champ_dev/champ_api/cmjadwal/getViewJadwal?dept=' . $dept);
        $jsons = $response->getBody()->getContents();
        $json = json_decode($jsons, true); 
         
        $dept = $json['dept'];
        $perd = $json['periode'];
        // dd($jadwal);
        return view('/jadwal/jadwal', compact( 'dept', 'perd', 'thr', 'bln'));

    }
}
