<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use View;

class CMAboutController extends Controller
{
    // http://api.champ-group.com/champs-mobile/public/cri_profiel
    public function cri_profiel(Request $request)
    {
        // $waktu = date('H-i-s');
        // $tanggals = date('Y-m-d');
        // $tanggal = Carbon::parse($tanggals)->translatedFormat('l, d F Y');
        $client = new \GuzzleHttp\Client();

        // $response = $client->get('http://localhost/champ_dev/champ_api/cmfiturweb/getAllOutlet');
        // $jsons = $response->getBody()->getContents();
        // $json = json_decode($jsons, true);
        // $alloutlet = $json['dftr_outlet'];
        // dd("Aaaaa");
        return view('/about/cri_profiel');
    }

}
