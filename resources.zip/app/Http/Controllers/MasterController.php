<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Session;
use View;

class MasterController extends Controller
{

    // http://api.champ-group.com/champs-mobile/public/master?nmapprovl=ahmad%20sobari
    public function master(Request $request)
    {

        $waktu = date('H-i-s');
        $tanggals = date('Y-m-d');
        $tanggal = Carbon::parse($tanggals)->translatedFormat('l, d F Y');
        $client = new \GuzzleHttp\Client();
        $nm = $_GET['nmapprovl'];

        $response = $client->get('http://api.champ-group.com/champ_dev/champ_api/cmfiturweb/getimeiapprove?nmapprovl=' . $nm);

        $jsons = $response->getBody()->getContents();
        $json = json_decode($jsons, true);
        if (isset($json['dfrgnti'])) {
            $dfrgnti = $json['dfrgnti']; 
        } else {
            $dfrgnti ='0'; 
        }
        // dd($dfrgnti);
        $request->session()->put('nmapprove', $nm);
        return view('/master/master', compact('dfrgnti'))->with('nmapprove');

    }

    public function master_gantiimei(Request $request)
    {

        // a_nip, a_dvcimei, a_dvchp, a_nm, a_con
        $client = new \GuzzleHttp\Client();
        $nip = $request->input('a_nip');
        $approval = session('nmapprove');
        $afnmdvc = $request->input('a_dvchp');
        $afiddvc = $request->input('a_dvcimei');
        $nmnip = $request->input('a_nm');
        $cont = $request->input('a_con');
        // afiddvc ,afnmdvc ,  nip
        // dd($nip  . "===" . $approval . "===" . $afnmdvc . "===" . $afiddvc);
        $response = $client->post('http://api.champ-group.com/champ_dev/champ_api/cmfiturweb/setupdateimei', [
            'form_params' => [
                'nip' => $nip,
                'approval' => $approval,
                'afnmdvc' => $afnmdvc,
                'afiddvc' => $afiddvc,
            ],
        ]
        );
        $jsons = $response->getBody()->getContents();
        $json = json_decode($jsons, true);
        $gtniimei = $json['gtniimei'];

        if ($gtniimei == 'true') {
            $msg = 'Success! ' . $nmnip . ' (' . $nip . ') Sudah melakukan reset imei sebanyak ' . $cont . ' kali';
            $stt = '1';
        } else {
            $msg = 'Gagal Update perangkat! ';
            $stt = '0';
        }
        $aa = str_replace(" ", "%20", $approval);
        // dd($msg);
        return redirect('/master?nmapprovl=' . $aa)->with(['msg' => $msg, 'stt' => $stt]);
    }

    public function master_resetpass(Request $request)
    {
        $client = new \GuzzleHttp\Client();
        $nip = $request->input('pass_nip');
        $approval = session('nmapprove');

        $response = $client->post('http://api.champ-group.com/champ_dev/champ_api/cmfiturweb/setResetPass', [
            'form_params' => [
                'nip' => $nip,
            ],
        ]
        );
        $jsons = $response->getBody()->getContents();
        $json = json_decode($jsons, true);
        $jmessage = $json['message'];
        $jsuccess = $json['success'];
        if ($jsuccess == 1) {
            $jnmlngkp = $json['nm_lengkap'];
        }
        $aa = str_replace(" ", "%20", $approval);
        // dd("==" . $jsuccess . "==" . $aa);

        return redirect('/master?nmapprovl=' . $aa)->with(['jmessage' => $jmessage, 'jsuccess' => $jsuccess]);
    }

}
