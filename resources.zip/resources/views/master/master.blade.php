@extends('layouts.layout')
@section('title', 'PT.Champ Resto Indonesia')
@section('content')
@include('modal.m_master')



<div class="container" style="padding-top: 70px;">
    <div class="card-deck mb-3 ">
        <div class="card mb-4 shadow-sm">
            <div class="card-header">
                <h4 class="my-0 font-weight-normal">Master</h4>
            </div>
            <div class="card-body">

                <div class="fw-container">

                    <div class="fw-body">

                        <div class="content">
                            <div class="input-group mb-3">
                                <input id="myCustomSearchBox" type="text" class="form-control" placeholder="Searching"
                                    aria-label="Search Anything here" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button onclick="document.getElementById('dpassword').style.display='block'"
                                        class="btn btn-success" type="button">Reset
                                        Password</button>
                                </div>
                            </div>

                            @if($dfrgnti == '0')

                            <div class="text-center ">
                                <lottie-player src="https://assets9.lottiefiles.com/packages/lf20_evqse4gh.json"
                                    background="transparent" speed="1"
                                    style="margin: 0 auto; width: 300px; height: 300px;" loop autoplay>
                                </lottie-player>
                                <h5 class="text-center">Tidak Ada data</h5>
                            </div>
                            @else

                            <table id="tb_master" class="display nowrap " style="width:100%">
                                <thead>
                                    <tr>
                                        <th style="border-top: 1px solid #111 !important;">No.</th>
                                        <th style="border-top: 1px solid #111 !important;">Name</th>
                                        <th style="border-top: 1px solid #111 !important;">NIP</th>
                                        <th style="border-top: 1px solid #111 !important;">Jabatan</th>
                                        <th style="border-top: 1px solid #111 !important;">Dept</th>
                                        <!--                    <th>Imie</th>-->
                                        <th style="border-top: 1px solid #111 !important;">Model</th>
                                        <th style="border-top: 1px solid #111 !important;">status</th>
                                        <th style="border-top: 1px solid #111 !important;">Date</th>
                                        <th style="border-top: 1px solid #111 !important;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no2 = 1; ?>
                                    @foreach ($dfrgnti as $arrygnti)
                                    <tr>

                                        <td>
                                            <?php echo $no2; ?>
                                        </td>
                                        <td class="text-left">{{Str::substr($arrygnti['nm_lengkap'],0,15)}} </td>
                                        <td>{{$arrygnti['nip']}}</td>
                                        <td>{{$arrygnti['jabatan']}}</td>
                                        <td>{{$arrygnti['nmoutlet']}}</td>
                                        <td>{{$arrygnti['bfnmdvc']}}
                                        </td>
                                        <td>{{$arrygnti['ket']}}
                                        </td>
                                        <td>{{$arrygnti['wktreq']}}
                                        </td>
                                        <td><a class='btn btn-sm btn-primary ' title='Approve'><i class='fa fa-pencil'
                                                    style='color: #fff '
                                                    onclick="diklik('{{$no2}}#{{$arrygnti['nm_lengkap']}}#{{$arrygnti['nip']}}#{{$arrygnti['bfnmdvc']}}#{{$arrygnti['bfiddvc']}}#{{$arrygnti['xcount']}}')"></i></a>
                                        </td>
                                    </tr>
                                    <?php $no2++; ?>
                                    @endforeach

                                </tbody>
                            </table>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- custom -->
{{-- <footer @if ($no2 < 9) class="footer fixed-bottom " @else class="footer" @endif> --}}


    <script>
        $.ajax({
        //other parameters
        success: function () {
        $("#id_footerr").addClass('fixed-bottom');
        }
        });
    function showmodal_done() { 
    $('#modal_baking').modal('show'); 
} 
    </script>

    <script>
        function diklik(isi) { 
        
        $('#modal_inptqty').modal('show');
        document.getElementById('modl_imei').style.display = 'block'; 
        var data = isi.split('#');
        var no = data[0];
        var nma = data[1];
        var nip = data[2];
        var nmd = data[3];
        var mei = data[4]; 
        var con = data[5]; 
        $('#a_id').val(no);
        $('#a_nm').val(nma); 
        $('#a_nip').val(nip); 
        $('#a_dvchp').val(nmd);
        $('#a_dvcimei').val(mei); 
        $('#a_con').val(con);
        document.getElementById("isi_modal").innerHTML = "Apakah anda yakin akan merubah perangkat, " + nma + " (" + nmd + ") ?";
        // When the user clicks anywhere outside of the modal, close it


    }
 
    </script>
    @if (session('jsuccess') == '1')
    <script>
        Swal.fire({
        icon: 'success',
        title: 'Success',
        text: "{{session('jmessage')}}",
        confirmButtonColor: '#3085d6',
        allowOutsideClick: false 
    })
    $('#loader').hide();
    </script>
    @elseif(session('jsuccess') == '0')
    <script>
        Swal.fire({
        icon: 'error',
        title: 'Opps!!',
        text: "{{session('jmessage')}}",
        confirmButtonColor: '#d33',
        allowOutsideClick: false
    })
    $('#loader').hide();
    </script>
    @endif

    @if (session('stt') == '1')
    <script>
        Swal.fire({
        icon: 'success',
        title: 'Success',
        text: "{{session('msg')}}" ,
        confirmButtonColor: '#3085d6',
        allowOutsideClick: false 
    })
    $('#loader').hide();
    </script>
    @elseif(session('stt') == '0')
    <script>
        Swal.fire({
        icon: 'error',
        title: 'Opps!!',
        text: "{{session('msg')}}" ,
        confirmButtonColor: '#d33',
        allowOutsideClick: false
    })
    $('#loader').hide();
    </script>
    @endif
    @endsection