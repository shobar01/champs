@extends('layouts.layout')
@section('title', 'PT.Champ Resto Indonesia')
@section('content')
@include('rptorderbrg.m_dwonldf')
<style>
    .btn-sm {
        padding: 5px;
    }

    .table-bordered td,
    .table-bordered th {
        padding-top: 0;
        padding-bottom: 0;
        font-size: 14px;
    }

    tr.detail-row {
        display: none
    }

    tr.detail-row.open {
        display: block;
        display: table-row;
        background-color: #febf014b;
    }

    tr.detail-row.open:hover {
        background-color: #FEBD01;
    }

    tr.detail-row>td {
        border-top: 3px solid #d1e1ea !important;
    }
</style>
<div class="container" style="padding-top: 70px; padding-right: 0px ; padding-left: 0px; ">
    <div class="card-deck mb-3 ">
        <div class="card mb-4 shadow-sm">
            <div class="card-header">

                <div class="row ">

                    <div class="col-md-6">
                        <a class="my-0 font-weight-normal " style="font-size: 14px;"><b>Report Order Barang
                                ({{$kdbrng}})</b></a>
                    </div>

                    <div class="col-md-6">
                        <a class="my-0 font-weight-normal " style="font-size: 14px;"><b>{{$tanggalll}}</b></a>
                    </div>
                </div>
            </div>
            <div class="card-body">

                <form id="send_perioderpt" class="" action="{{ route('repot_ob') }}" method="GET">
                    @csrf

                    <input type="hidden" class="" name="dwnld_type" id="dwnld_type" />
                    <input type="hidden" name="kdotl" id="kdotl" value="{{$ikdoutlet}}">
                    <input type="hidden" name="kdakses" id="kdakses" value="{{$kdakses}}">
                    <input type="hidden" name="nip" id="nip" value="{{$nip}}">
                    <input type="hidden" name="kdoutlet" id="kdoutlet" value="{{$ikdoutlet}}">
                    @if ($kdakses != 'AVMS2')
                    <div class="input-group mb-1">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon3"
                                style="font-size: 14px; color:black; min-width: 140px;">Outlet</span>
                        </div>

                        <select class="form-control" name="toglekdotl" id="toglekdotl" onchange="pilihkdotl()">
                            @foreach ($dfotl as $otl)
                            <option value="{{ $otl['kdoutlet'] }}" @if ($ikdoutlet==$otl['kdoutlet'] ) selected @endif>
                                {{$otl['sngktotl'] }} ({{ $otl['kdoutlet'] }})
                            </option>
                            @endforeach
                        </select>
                    </div>
                    @endif
                    <div class="input-group mb-1">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon3"
                                style="font-size: 14px; color:black; min-width: 140px;">Tanggal
                            </span>
                        </div>

                        <input type="date" name="tanggal_ordbrg" id="tanggal_ordbrg" value="{{$itgl}}"
                            class="form-control date_now" style="font-size: 14px; color:black;" onchange="pilihkdotl()"
                            required>
                    </div>
                    @if($jmlkdord > 1)

                    <input type="hidden" name="txkdorgbrg" id="txkdorgbrg" value="{{$kdbrng}}">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon3"
                                style="font-size: 14px; color:black; min-width: 140px;">Pilih Kode Order
                            </span>
                        </div>
                        <select class="form-control" name="toglekdorgbrg" id="toglekdorgbrg" onchange="pilihkdorgbrg()">
                            @foreach ($dfkdbrng as $dfbrg)
                            <option value="{{ $dfbrg['kdordbarang'] }}" @if ($kdbrng==$dfbrg['kdordbarang'] ) selected
                                @endif>
                                {{$dfbrg['kdordbarang'] }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    @endif

                    <div class="form-group ">

                        @if(isset($detail))
                        <button class="btn btn-danger btn-lg col-md-3 mt-1 float-right mb-1" type="button"
                            onclick="periode_tgl('btn_pdf')"><i class="fa fa-file-pdf-o" title="Download PDF">
                                Export PDF</i></button>
                        @endif
                    </div>

                </form>

                {{-- Tabel content --}}
                <div class="fw-container" style="margin-top: 1%;">
                    <div class="fw-body">
                        <div class="content">

                            @if(isset($detail))
                            <table id="tb_ordbrg" class="display nowrap " style="width:100%; ">
                                <thead>
                                    {{-- <tr style="background: #E99D03;"> --}}
                                    <tr>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important">
                                            No.</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Kode</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Satuan</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Qty</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Nama</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Kode Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($dford as $arrydetail)
                                    <tr>
                                        <td style="font-size: 12px !important;">
                                            {{$loop->iteration}}</td>
                                        <td style="font-size: 12px !important;">{{$arrydetail['kdbarang']}} </td>
                                        <td style="font-size: 12px !important;">{{$arrydetail['satuan']}} </td>
                                        <td style="font-size: 12px !important;">{{$arrydetail['qty']}} </td>
                                        <td style="font-size: 12px !important;">
                                            {{ucfirst(strtolower($arrydetail['nmbarang']))}}</td>
                                        <td style="font-size: 12px !important;">{{$arrydetail['kdorderbarang']}} </td>
                                    </tr>
                                    @endforeach
                                <tfoot>
                                    <tr>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            No.</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Kode</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Satuan</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Qty</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Nama</th>
                                        <th style="border-top: 1px solid #111 !important; font-size: 12px !important;">
                                            Kode Order</th>
                                    </tr>
                                </tfoot>
                                </tbody>
                            </table>
                            @else
                            <div class="text-center ">
                                <lottie-player src="https://assets9.lottiefiles.com/packages/lf20_evqse4gh.json"
                                    background="transparent" speed="1"
                                    style="margin: 0 auto; width: 300px; height: 300px;" loop autoplay>
                                </lottie-player>
                                <h5 class="text-center">Tidak ada data</h5>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


<script>
    $.ajax({
        //other parameters
        success: function () {
        $("#id_footerr").addClass('fixed-bottom');
        }
        });
</script>
<script>
    function pilihkdotl(){ 
    var toglekdotl = $('#toglekdotl').val();
    $('#kdotl').val(toglekdotl); 
    $('#dwnld_type').val('btn_periode');  
    $('#send_perioderpt').submit(); 
}
function pilihkdorgbrg(){ 
    var toglekdotl = $('#toglekdotl').val();
    $('#kdotl').val(toglekdotl); 
    $('#dwnld_type').val('btn_periode'); 
    var toglekdorgbrg = $('#toglekdorgbrg').val();
    $('#txkdorgbrg').val(toglekdorgbrg); 
    $('#send_perioderpt').submit();
}
function periode_tgl(diklik){
 
    var toglekdotl = $('#toglekdotl').val();
    $('#kdotl').val(toglekdotl);  
    $('#dwnld_type').val(diklik);    
    $('#send_perioderpt').submit(); 
}
</script>

@endsection

{{-- <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js">
</script> --}}