<div class="modal fade" id="detailexpanse" tabindex="-1" role="dialog" aria-labelledby="detailexpanseLabel"
    aria-hidden="true"  style="margin-top: 70px;">
    <div class="modal-dialog modal-lg w3-animate-bottom fixed-bottom m-0" role="document">
        <div class="modal-content color-card">
            <div class="modal-header pb-1">
                <h5 style="font-weight:bold; padding:0;">Detail Expense</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"> &times;</span>
                </button>
            </div>

            {{-- <div class="modal-body pt-0"> --}}

                <ul id="detailisiexpense"
                    style="overflow-x: hidden; height: 450px; list-style-type: none; padding: 5px;">
                </ul>

                {{--
            </div> End modal body --}}
        </div>
    </div>
</div>
<a id="cetakexpense" download></a>