@extends('layouts.layout_cmmodal')
@section('title', 'PT.Champ Resto Indonesia Tbk.')
@section('content')
<style>
    .user {
        display: flex;
        margin-top: auto;
        min-width: 100%;
    }

    .user img {
        border-radius: 50%;
        width: 40px;
        height: 40px;
        margin-right: 10px;
    }

    .user-info h5 {
        margin: 0;
    }

    .user-info small {
        color: #545d7a;
    }
</style>
<div class="container" style="padding:10px;">
    <div class="card-deck mb-3 ">
        <div class="card mb-4 shadow-sm">
            <div class="card-header" style="padding: 0.50rem 0.50rem !important;">
                <div class="row">
                    <div class="col">
                        <a class="my-0 font-weight-normal" style="font-size: 16px;"><b>History</b></a>
                    </div>
                    {{-- <div class="col text-right">
                        <a type="button" class="btn-sm btn-white shadow"
                            href="{{ route('cm_dashsaranHistory')}}?urllotti={{$urllotti}}&nip={{$nip}}&kdoutlet={{$kdoutlet}}&kdakses={{$kdakses}}&idtittle={{$idtittle}}"
                            style="border-radius: 5px !important; background-color: white; 
                        color:red; font-weight: bold; font-size: 12px;">History</a>
                    </div> --}}
                </div>
                {{-- <a class="my-0 font-weight-normal" style="font-size: 14px;"><b>Suara Karyawan</b></a> --}}

            </div>
            @if(isset($dfhis_mood))
            <div class="card-body text-left">
                <ul style="overflow-x: hidden; height: 255px; list-style-type: none; padding: 5px;">
                    @foreach ($dfhis_mood as $dfmood)
                    <div class="col-md-12" style="padding: 0px  0px  0px  0px !important;">
                        <div class="card-header shadow mt-2"
                            style="background-color: #FFFFFF !important; border-radius: 5px !important; padding: 5px 5px 5px 5px !important;">
                            <div class="user">
                                <div class=" img text-center" style="">
                                    <lottie-player class="shadow" src="{{$dfmood['UrlCat']}}" background="transparent"
                                        speed="1" style="margin: 0 auto; width: 25px; height: 25px; border-radius: 5px;"
                                        loop autoplay>
                                    </lottie-player>
                                    <span class=" " id="basic-addon3"
                                        style="color:black; height: 17px; font-size: 12px;  ">
                                        {{$dfmood['Tittle']}}
                                    </span>
                                </div>
                                <div class="user-info" style="padding-left: 10px; min-width: 95%;">
                                    <div class="input-group input-group-sm ">
                                        <span class=" " id="basic-addon3"
                                            style="color:black;min-width: 90%; margin: 0px 10px 0px 0px;   font-size: 12px;  ">
                                            {{$dfmood['isisaran']}}
                                        </span>
                                    </div>
                                    <div class="row">
                                        <div class=" text-right"
                                            style="height: 17px; color:black; min-width: 90%; margin: 10px 10px 0px 0px;  font-size: 10px;">
                                            {{$dfmood['wktsrn']}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </ul>
            </div>
            @else

            <div class="text-center ">
                <lottie-player src="https://assets9.lottiefiles.com/packages/lf20_evqse4gh.json"
                    background="transparent" speed="1" style="margin: 0 auto; width: 300px; height: 300px;" loop
                    autoplay>
                </lottie-player>
                <h5 class="text-center">Tidak Ada data</h5>
            </div>

            @endif
        </div>

    </div>
</div>

<script>
</script>
@endsection