@extends('layouts.layout')
@section('title', 'PT.Champ Resto Indonesia')
@section('content')

<div class="container" style="padding-top: 70px;">
    <div class="card-deck mb-3 ">
        <div class="card mb-4 shadow-sm">
            <div class="card-header">
                <h4 class="my-0 font-weight-normal">Presence</h4>
            </div>
            <div class="card-body">

                <form id="send_periode" class="" action="{{route('presence_periode')}}" method="POST" class="d-none">
                    @csrf

                    <input type="hidden" class="" name="perid_bln" id="perid_bln" />
                    <input type="hidden" class="" name="perid_thn" id="perid_thn" />
                    <div class="row">
                        <div class="col-5 " style="padding-right : 0px; !important">
                            <select class="form-control form-control-sm " id="bln_select">
                                <option value="01">Januari</option>
                                <option value="02">Februari</option>
                                <option value="03">Maret</option>
                                <option value="04">April</option>
                                <option value="05">Mei</option>
                                <option value="06">Juni</option>
                                <option value="07">Juli</option>
                                <option value="08">Agustus</option>
                                <option value="09">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                        </div>
                        <div class="col-3" style="padding-right : 0px; !important">
                            <select class="form-control form-control-sm " id="thn_select">
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                            </select>
                        </div>
                        <div class="col-4 justify-content-end d-flex">
                            <button class="btn btn-success btn-sm btn-block" type="submit"
                                onclick="periode()">Periode</button>
                        </div>
                    </div>
                    {{-- Tabel content --}}
                    <div class="fw-container" style="margin-top: 1%;">
                        <div class="fw-body">
                            <div class="content">
                                <div class="input-group mb-3">
                                    <input id="search_absen" type="text" class="form-control" placeholder="Searching"
                                        aria-label="Search" aria-describedby="basic-addon2">
                                </div>

                                <table id="tb_presence" class="display nowrap " style="width:100%; ">
                                    <thead>
                                        {{-- <tr style="background: #E99D03;"> --}}
                                        <tr>
                                            <th style="border-top: 1px solid #111 !important;">No.</th>
                                            <th style="border-top: 1px solid #111 !important;">Tanggal</th>
                                            <th style="border-top: 1px solid #111 !important;">Hadir</th>
                                            <th style="border-top: 1px solid #111 !important;">Istirahat</th>
                                            <th style="border-top: 1px solid #111 !important;">Lokasi</th>
                                            <th style="border-top: 1px solid #111 !important;">Durasi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no2 = 1; ?>
                                        @foreach ($absensi as $arryabsensi)
                                        <tr>
                                            <td>
                                                <?php echo $no2; ?>
                                            </td>
                                            <td>{{$arryabsensi['tgl']}}</td>
                                            <td>{{$arryabsensi['hdr']}} </td>
                                            <td>{{$arryabsensi['istrht']}} </td>
                                            <td>{{$arryabsensi['otl']}} </td>
                                            <td>{{$arryabsensi['dur1']}} </td>
                                        </tr>
                                        <?php $no2++; ?>
                                        @endforeach
                                    <tfoot>
                                        <tr>
                                            <th style="border-bottom: 1px solid #111 !important;">No.</th>
                                            <th style="border-bottom: 1px solid #111 !important;">Tanggal</th>
                                            <th style="border-bottom: 1px solid #111 !important;">Hadir</th>
                                            <th style="border-bottom: 1px solid #111 !important;">Istirahat</th>
                                            <th style="border-bottom: 1px solid #111 !important;">Lokasi</th>
                                            <th style="border-bottom: 1px solid #111 !important;">Durasi</th>
                                        </tr>
                                    </tfoot>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

            </div>
        </div>

    </div>
</div>
<!-- custom -->
{{-- <footer @if ($no2 < 9) class="footer fixed-bottom " @else class="footer" @endif> --}}


    <script>
        $("#bln_select option[value='{{session('blncm')}}']").attr("selected", "selected"); 
    $("#thn_select option[value='{{session('thncm')}}']").attr("selected", "selected");
    // $("div.bln_select select").val("09").change();
    function showmodal_done() {
    $('#modal_baking').modal('show');
    }
    function periode(){
    var sValbln = $("#bln_select option:selected").val(); 
    var sValthn = $("#thn_select option:selected").val();
    var sValues = sValbln +"#"+sValthn;  
    $('#loader').show();   
    
        $('#perid_bln').val(sValbln);
        $('#perid_thn').val(sValthn);
    }
    </script>

    <script>
        function diklik(isi) { 
        
        $('#modal_inptqty').modal('show');
        document.getElementById('modl_imei').style.display = 'block'; 
        var data = isi.split('#');
        var no = data[0];
        var nma = data[1];
        var nip = data[2];
        var nmd = data[3];
        var mei = data[4]; 
        var con = data[5]; 
        $('#a_id').val(no);
        $('#a_nm').val(nma); 
        $('#a_nip').val(nip); 
        $('#a_dvchp').val(nmd);
        $('#a_dvcimei').val(mei); 
        $('#a_con').val(con);
        document.getElementById("isi_modal").innerHTML = "Apakah anda yakin akan merubah perangkat, " + nma + " (" + nmd + ") ?";
        // When the user clicks anywhere outside of the modal, close it 
    }
 
    </script>
    @if (session('jsuccess') == '1')
    <script>
        Swal.fire({
        icon: 'success',
        title: 'Success',
        text: "{{session('jmessage')}}",
        confirmButtonColor: '#3085d6',
        allowOutsideClick: false  
    })
    $('#loader').hide();
    </script>
    @elseif(session('jsuccess') == '0')
    <script>
        Swal.fire({
        icon: 'error',
        title: 'Opps!!',
        text: "{{session('jmessage')}}",
        confirmButtonColor: '#d33',
        allowOutsideClick: false 
    })
    $('#loader').hide();
    </script>
    @endif

    @if (session('stt') == '1')
    <script>
        Swal.fire({
        icon: 'success',
        title: 'Success',
        text: "{{session('msg')}}" ,
        confirmButtonColor: '#3085d6',
        allowOutsideClick: false  
    })
    $('#loader').hide();
    </script>
    @elseif(session('stt') == '0')
    <script>
        Swal.fire({
        icon: 'error',
        title: 'Opps!!',
        text: "{{session('msg')}}" ,
        confirmButtonColor: '#d33',
        allowOutsideClick: false 
    })
    $('#loader').hide();
    </script>
    @endif
    @endsection